<?php
// Entrada de respaldo: redirige al front controller respetando APP_BASE_PATH.
// Bajo el modo de Alias /oficios, este archivo NO deberia ser servido nunca,
// ya que el Alias apunta directamente a src/public. Se conserva como fallback.
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/core/UrlHelper.php';
redirect_to('/');
