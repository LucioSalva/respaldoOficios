<?php
/**
 * UrlHelper
 * Funciones globales para resolver URLs cuando la aplicacion vive bajo
 * una subcarpeta del host (por ejemplo /oficios) servida con Apache Alias.
 *
 * Reglas:
 *   base_path()        -> "" o "/oficios" (sin slash final).
 *   url_path('/foo')   -> base_path() + '/foo'  (relativo al host, para href/action internos).
 *   app_url('/foo')    -> APP_URL + base_path() + '/foo' (URL absoluta completa).
 *   asset_url('x.css') -> url_path('/assets/x.css') (con cache-buster cuando aplica).
 *   redirect_to('/x')  -> Location: url_path('/x'); exit;
 *
 * Si APP_BASE_PATH esta vacio, la semantica equivale a la version anterior:
 *   url_path('/foo')   -> '/foo'
 *   app_url('/foo')    -> APP_URL + '/foo'
 *   asset_url('x.css') -> '/assets/x.css'
 *
 * El cache-buster usa filemtime() del archivo en src/public/assets cuando es
 * accesible, para evitar problemas de cache tras un despliegue.
 */

if (!function_exists('base_path')) {
    function base_path(): string
    {
        if (defined('APP_BASE_PATH')) {
            return APP_BASE_PATH; // ya viene normalizada en config.php
        }
        return '';
    }
}

if (!function_exists('url_path')) {
    function url_path(string $path = '/'): string
    {
        if ($path === '' ) {
            $path = '/';
        }
        if ($path[0] !== '/') {
            $path = '/' . $path;
        }
        $base = base_path();
        if ($base === '') {
            return $path;
        }
        return $base . $path;
    }
}

if (!function_exists('app_url')) {
    function app_url(string $path = '/'): string
    {
        $host = defined('APP_URL') ? rtrim(APP_URL, '/') : '';
        return $host . url_path($path);
    }
}

if (!function_exists('asset_url')) {
    function asset_url(string $relative): string
    {
        $relative  = ltrim($relative, '/');
        $assetPath = '/assets/' . $relative;

        $abs = defined('ROOT_PATH') ? ROOT_PATH . '/public' . $assetPath : null;
        if ($abs && is_file($abs)) {
            $assetPath .= '?v=' . filemtime($abs);
        }

        return url_path($assetPath);
    }
}

if (!function_exists('redirect_to')) {
    function redirect_to(string $path): void
    {
        header('Location: ' . url_path($path));
        exit;
    }
}
