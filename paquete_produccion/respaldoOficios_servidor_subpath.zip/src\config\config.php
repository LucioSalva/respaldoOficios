<?php
/**
 * Configuración central de la aplicación
 * Carga variables de entorno y define constantes globales
 */

// Zona horaria
$tz = getenv('APP_TIMEZONE') ?: 'America/Mexico_City';
date_default_timezone_set($tz);

// Constantes de aplicación
define('APP_ENV',     getenv('APP_ENV')     ?: 'production');

// APP_DEBUG: en producción se FUERZA a false, pase lo que pase en .env.
// Esto evita que un despliegue accidental deje stack traces expuestos.
$__debugRaw = filter_var(getenv('APP_DEBUG') ?: 'false', FILTER_VALIDATE_BOOLEAN);
define('APP_DEBUG', APP_ENV === 'production' ? false : $__debugRaw);

define('APP_URL',     rtrim(getenv('APP_URL') ?: 'http://localhost:8080', '/'));
define('APP_SECRET',  getenv('APP_SECRET')  ?: 'default_insecure_secret_change_me');

// Ruta base bajo la cual vive la app cuando no es raiz del host.
// Ejemplo: APP_BASE_PATH=/oficios cuando se sirve via Apache Alias.
// Si esta vacia, la app vive en la raiz. NO debe terminar en "/".
$__basePathRaw = getenv('APP_BASE_PATH');
if ($__basePathRaw === false || $__basePathRaw === null) {
    $__basePathRaw = '';
}
$__basePathRaw = trim($__basePathRaw);
if ($__basePathRaw !== '' && $__basePathRaw[0] !== '/') {
    $__basePathRaw = '/' . $__basePathRaw;
}
$__basePathRaw = rtrim($__basePathRaw, '/');
define('APP_BASE_PATH', $__basePathRaw);

// Base de datos
define('DB_HOST', getenv('DB_HOST') ?: 'db');
define('DB_PORT', getenv('DB_PORT') ?: '5432');
define('DB_NAME', getenv('DB_NAME') ?: 'respaldo_oficios');
define('DB_USER', getenv('DB_USER') ?: 'oficios_user');
define('DB_PASS', getenv('DB_PASS') ?: '');

// Uploads
define('UPLOAD_DIR',      getenv('UPLOAD_DIR')      ?: dirname(__DIR__, 2) . '/uploads');
define('UPLOAD_MAX_SIZE', (int)(getenv('UPLOAD_MAX_SIZE') ?: 10485760)); // 10MB

// Sesión
define('SESSION_LIFETIME', (int)(getenv('SESSION_LIFETIME') ?: 7200));
define('SESSION_NAME',     getenv('SESSION_NAME')     ?: 'respaldo_oficios_sess');

// Rutas del proyecto
define('ROOT_PATH',  dirname(__DIR__));
define('VIEWS_PATH', ROOT_PATH . '/views');

// Directorio de logs privado (fuera de webroot). Se crea si no existe.
define('LOG_PATH',   ROOT_PATH . '/storage/logs');
if (!is_dir(LOG_PATH)) {
    @mkdir(LOG_PATH, 0750, true);
}

// Folio de tesorería - prefijo fijo institucional
define('FOLIO_PREFIJO', 'TM/ECA/STIyC');

// Roles
define('ROL_GOD',   1);
define('ROL_ADMIN', 2);
define('ROL_USER',  3);

// Error reporting según entorno
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', LOG_PATH . '/php_errors.log');
}

// Helpers globales de URL (app_url, asset_url)
require_once ROOT_PATH . '/core/UrlHelper.php';
